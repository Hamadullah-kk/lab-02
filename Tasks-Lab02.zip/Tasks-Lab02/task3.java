import java.util.Scanner;
class task3{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	  System.out.print("Enter the Number of rows of matrix 1 :");
   int rows = input.nextInt();
   System.out.print("Enter the Number of columns of matrix 1 :");
	int columns = input.nextInt();
 int[][] matrix = new int[rows][columns];

  for(int i = 0; i < matrix.length; i++){
  	for(int j = 0; j < matrix.length; j++){
  		matrix[i][j] = input.nextInt();
  	}
  }

  int sum = 0;
   System.out.println("Entered matrix is :");
   for(int i = 0; i < matrix.length; i++){
   	for(int j = 0; j < matrix.length; j++){
   		System.out.print(matrix[i][j]+" ");
      sum += matrix[i][j];
   	}
   	System.out.print("\n");
   }
   System.out.println("Sum of matrix is : "+sum);
   
	}
}