import java.util.Scanner;
class task4{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
        String[] names = {"Hamad","Zain","Mehran","Baqar","Masroor","Adil","Ali"};
      
         System.out.print("Enter the name that you want to find in array : ");

        String name = input.nextLine();
        if(name == "ali" || name == "Ali"){
            System.out.println("Ali is present in array.");
        }else{
            System.out.println("No! Ali is not present in array.");
        }

       
     
	}
}