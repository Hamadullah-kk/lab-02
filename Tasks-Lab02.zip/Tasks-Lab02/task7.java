import java.util.Scanner;
class task7{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the size of array : ");
		int size = input.nextInt();
		int[] array = new int[size];

 System.out.println("Enter the element of array. ");
	for(int i = 0; i < size; i++){
       System.out.print(i+1+" : ");
       array[i] = input.nextInt();
	}
    
    int smallest = array[0];
    int largest = array[0];

  for(int i = 0; i<size; i++){
    if(array[i] < smallest){
    	smallest = array[i];
    }
    if(array[i] > largest){
    	largest = array[i];
    } 
}
 if(largest%2==0){
 	System.out.println("-----The largest number "+largest+" is multiple of 2.-----");
 }else{
 	System.out.println("-----The largest number "+largest+" is not multiple of 2.-----");
 }

	}
}