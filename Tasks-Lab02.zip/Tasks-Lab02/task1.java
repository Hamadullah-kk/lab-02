import java.util.Scanner;
public class task1{
public static void main(String args[]){

char[] const_arr = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};

Scanner input = new Scanner(System.in);

 System.out.print("Enter any english letter :");
 
  char user_input = input.next().charAt(0);
 
  for(int i = 0; i < const_arr.length; i++){
  
  if(user_input != const_arr[i]){
        System.out.println("This letter is not exist in array. ");}
    else{
       System.out.println("This letter is exist in array. ");}
         } 
 } 
  }

