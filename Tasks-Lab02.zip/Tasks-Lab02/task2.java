import java.util.Scanner;
class task2{
	public static void main(String args []){
 Scanner input = new Scanner(System.in);
	int[] array = new int[10];
	for(int i =0; i<array.length; i++){
		System.out.println("Inder number is"+ i +"value is"+array );
	}
		
	for(int i = 0; i<array.length; i++){
	  System.out.print("Enter the values : ");
		array[i] = input.nextInt();
}
    double sum = 0;
	for(int i = 0; i<array.length; i++){		
		if(array[i] % 4 == 0){
			sum += array[i];
      
		}}
    System.out.println("The sum of multiples of 4 is : " + sum);
	}
}