import java.util.Scanner;
class task5{
	public static void main(String[] args){
		int[][] matrix = {{1,1,0,0,1},
		                 {1,0,1,0,1},
		                 {1,0,0,1,1},
		                 {1,0,0,0,1}};
		  if(matrix[0][1]==1 || matrix[1][2]==1 || matrix[2][3]==1 || matrix[3][4]==1){
		  	System.out.println("Yes matrix contains the letter 'N'. ");
		  }else{
		  	System.out.println("No matrix is not contins the letter 'N'. ");
		  }               
	}
}